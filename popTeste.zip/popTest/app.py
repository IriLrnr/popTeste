from flask import Flask, render_template, flash, redirect, url_for, session, logging, request
from data import Users
from flask_mysqldb import MySQL
from wtforms import Form, StringField, TextAreaField, PasswordField, validators, BooleanField
from passlib.hash import sha256_crypt

app = Flask(__name__)

# Config MySQL
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'root'
app.config['MYSQL_DB'] = 'pOp'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'
# Init MySQL
mysql = MySQL(app)

Users = Users()

@app.route('/')
def index():
     return render_template('login.html')

@app.route('/menu')
def menu():
    return render_template('menu.html')

@app.route('/users')
def users():
    return render_template('users_adm.html', users = Users)

class RegisterForm(Form):
    email = StringField('Email', [validators.Length(min=5, max=50)])
    password = PasswordField('Password', [
        validators.DataRequired(), validators.EqualTo('confirm', message='Passwords do not match')])
    confirm = PasswordField('Confirm Password')

@app.route('/cadastro', methods=['GET', 'POST'])
def register():
    form = RegisterForm(request.form)
    if request.method == 'POST' and form.validate():
        email = form.email.data
        password = sha256_crypt.encrypt(str(form.password.data))

        # Create cursor
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO users(email, password), VALUES (%s, %s)" (email, password))

        #commit
        mysql.connection.commit()

        #close connection
        cur.close()

        flash("You are now registered.", 'sucess')

        redirect(url_for('login'))

    return render_template('cadastro.html', form=form)

if __name__ == '__main__':
    app.secret_key='secret123'
    app.run (debug = True)
