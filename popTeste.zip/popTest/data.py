def Users():
    users = [
        {
            'id': 1,
            'email': 'iri@email.com',
            'password': 1234
        }
    ]
    return users
